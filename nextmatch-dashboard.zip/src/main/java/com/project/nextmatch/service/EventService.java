package com.project.nextmatch.service;

import com.project.nextmatch.domain.Event;
import com.project.nextmatch.domain.Member;
import com.project.nextmatch.dto.EventCreateRequest;
import com.project.nextmatch.repository.EventRepository;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class EventService {

    private final EventRepository eventRepository;
    // private final MemberRepository memberRepository; // Member 객체 조회를 위해 필요하다고 가정

    // --- 대회 생성 메서드 (EventController 오류 해결) ---
    // 데이터 변경이 일어나므로 @Transactional(readOnly = false)로 설정합니다.
    @Transactional
    public Long createEvent(EventCreateRequest request) {
        // 실제로는 MemberRepository를 이용해 작성자(Member)를 찾아야 합니다.
        // Member member = memberRepository.findById(request.getMemberId())
        //                     .orElseThrow(() -> new IllegalArgumentException("작성자를 찾을 수 없습니다."));

        // 임시 Member 객체 (컴파일용)
        Member member = Member.builder().id(request.getMemberId()).username("test_user").password("").build();

        Event newEvent = Event.builder()
                .title(request.getTitle())
                .eventCategory(request.getEventCategory())
                .description(request.getDescription())
                .eventDate(request.getEventDate())
                .deadlineDate(request.getDeadlineDate())
                .imageUrl(request.getImageUrl())
                .member(member) // Member 객체 설정
                .status("CREATED")
                .build();

        Event savedEvent = eventRepository.save(newEvent);
        return savedEvent.getId();
    }

    // --- 대회 목록 조회 (지연 로딩 문제 해결) ---
    public List<EventListResponse> getEventList() {
        // JOIN FETCH 쿼리를 사용하여 Event와 Member를 한 번에 로드합니다.
        List<Event> events = eventRepository.findAllWithMember();

        // 트랜잭션 범위 안에서 DTO로 변환하여 반환합니다.
        return events.stream()
                .map(EventListResponse::new)
                .collect(Collectors.toList());
    }

    // --- EventListResponse DTO 정의 (EventController 반환 타입) ---
    @Getter
    public static class EventListResponse {
        private final Long id;
        private final String title;
        private final String eventCategory;
        private final LocalDate eventDate;
        private final String memberUsername; // 필드명을 'memberUsername'으로 명확히 변경

        public EventListResponse(Event event) {
            this.id = event.getId();
            this.title = event.getTitle();
            this.eventCategory = event.getEventCategory();
            this.eventDate = event.getEventDate();

            // Member 엔티티의 필드명 'username'에 맞춰 getUsername() 호출 (이전 컴파일 오류 해결)
            this.memberUsername = event.getMember().getUsername();
        }
    }
}