package com.project.nextmatch.repository;

import com.project.nextmatch.domain.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface EventRepository extends JpaRepository<Event, Long> {

    // 지연 로딩 예외(LazyInitializationException)와 N+1 쿼리 문제를 해결합니다.
    @Query("SELECT e FROM Event e JOIN FETCH e.member")
    List<Event> findAllWithMember();
}